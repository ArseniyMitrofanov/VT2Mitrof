package by.bsuir.wt.second.service.validator;

public interface Validator {
    boolean isValid(String expression);
}
