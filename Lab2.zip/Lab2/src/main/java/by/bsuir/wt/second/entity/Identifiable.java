package by.bsuir.wt.second.entity;

public interface Identifiable {
    int getId();
}
