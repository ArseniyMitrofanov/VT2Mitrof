package by.bsuir.wt.second.controller.command;

public enum CommandResultType {
    FORWARD, REDIRECT
}
