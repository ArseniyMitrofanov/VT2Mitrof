package by.bsuir.wt.second.dao;

public class Table {
    public static final String USER = "Users";
    public static final String ORDER = "Orders";
    public static final String ROLE = "Roles";
    public static final String USER_INFORMATION = "UserInformation";
    public static final String USER_ORDER = "UserOrders";
    public static final String APARTMENTS = "Apartments";
}
